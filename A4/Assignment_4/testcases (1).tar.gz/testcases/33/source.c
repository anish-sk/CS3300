int main() {

    int a;
    int b;

    scanf("%d", &a);


    {
        int z;
	b = 33;
    }


    if ( a > 10 ) {
        int t;
        printf("%d\n", a);
    } else {
        int y;
        printf("%d\n", a);
    }
    return 0;
}

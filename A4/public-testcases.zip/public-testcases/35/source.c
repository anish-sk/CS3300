int main() {

    int a;
    int b;
    int c;
    int d;
    int e;

    scanf("%d", &a);
    scanf("%d", &b);

    if ( a != 20) {
        c = 10;
        printf("%d\n", a);
    } else {
        d = 20;
        printf("%d\n", b);
    }

    return 0;
}

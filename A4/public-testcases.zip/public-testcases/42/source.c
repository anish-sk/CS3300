int main() {

    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;

    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);
    scanf("%d", &d);
    scanf("%d", &e);


    f = 10;
    h = 2;
    i = h + 4;

    if ( (f+13) > 12) {
        g = a;
        a = a * f;
    } else {
        g = 31;
        i = h + 4;
    }

    h = (f+3) * 4;
    i = h + 4;
    i = i + 4;

    printf("%d\n", g);
    printf("%d\n", h);
    printf("%d\n", i);

    return 0;
}

int main() {

	int a;
	int b;
	int c;
	int z;
	int q;
	int d;
	int x;
	int y;

	x = 1;
	scanf("%d", &y);
	a = 1;
	c = (a - (a * 3)) + x;
	d = c * (x + ((5*4)*a));
	b = (127 + a) * x;
	if((6*d)+(b-2)){
		c = 1;
		d = 25;
		b = 5;
		b = b + d;
		z = c*d;
		printf("%d\n", b);
		printf("%d\n", d);
	}
	else{
		x = (c*d) + (c + (d * b));
		c = 1;
		y = (c + (d * b)) - (b*c);
		printf("%d\n", x);
		printf("%d\n", y);
	}

	return 0;
}

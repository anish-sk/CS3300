int main() {

    int a;

    scanf("%d", &a);


    {
        int z;
        a = a;
    }


    if ( a > 10 ) {
        int t;
        printf("%d\n", a);
    } else {
        int y;
        printf("%d\n", a);
    }
    return 0;
}

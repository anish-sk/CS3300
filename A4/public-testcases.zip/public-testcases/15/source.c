int main() {

	int a;
	int b;
	int c;
	int x;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);

	z = ((a+ (b*3)) + ((1-2)*45))*((12*33) - (11*34));
	x = (a*b) + ((a+b) + (300 + 200));
	c = (a*(b*(3*7))) - (3*8);


	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", x);
	printf("%d\n", z);

	return 0;
}

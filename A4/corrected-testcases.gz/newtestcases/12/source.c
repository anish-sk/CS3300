int main() {

	int a;
	int b;
	int c;
	int d;
	int x;
	int y;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);
	c = (a + b) + ((a*b) * (3 * 4));
	z = (12 + (25*4)) + (25-9);
	x = (4 - 2);
	d = (a*(100*(100+4)))-((25*4)*b);
	y = a + b;

	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", d);
	printf("%d\n", y);

	return 0;
}

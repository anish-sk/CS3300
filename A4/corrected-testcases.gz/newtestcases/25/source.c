int main() {

    int a1;
    int a2;
    int a3;
    int a4;
    int a5;
    int a6;
    int a7;
    int a8;
    int a9;
    int a10;
    int a11;
    int a12;
    int a13;
    int a14;
    int a15;
    int a16;
    int a17;
    int a18;
    int a19;
    int a20;
    int a21;
    int a22;
    int a23;
    int a24;
    int a25;
    int a26;
    int a27;


    scanf("%d", &a1);
    scanf("%d", &a2);
    scanf("%d", &a3);
    scanf("%d", &a4);
    scanf("%d", &a5);
    scanf("%d", &a6);
    scanf("%d", &a7);
    scanf("%d", &a8);
    scanf("%d", &a9);
    scanf("%d", &a10);
    scanf("%d", &a11);
    scanf("%d", &a12);
    scanf("%d", &a13);
    scanf("%d", &a14);
    scanf("%d", &a15);
    scanf("%d", &a16);
    scanf("%d", &a17);
    scanf("%d", &a18);
    scanf("%d", &a19);
    scanf("%d", &a20);
    scanf("%d", &a21);
    scanf("%d", &a22);
    scanf("%d", &a23);
    scanf("%d", &a24);
    scanf("%d", &a25);
    scanf("%d", &a26);


    a27 = (a1 + a2);
    a15 = ((a1 + a2) + a3);
    a16 = (((a1 + a2) + a3) + a4);
    a17 = ((((a1 + a2) + a3) + a4) + a5);
    a18 = (((((a1 + a2) + a3) + a4) + a5) + a6);
    a19 = (((((a1 + a2) + a3) + a4) + a5) + a6) + a7;
    a20 = (((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8);
    a21 = ((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9);
    a22 = (((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9) + a10);
    a23 = ((((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9) + a10) + a11);
    a24 = (((((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9) + a10) + a11) + a12);
    a25 = ((((((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9) + a10) + a11) + a12) + a13);
    a26 = (((((((((((((a1 + a2) + a3) + a4) + a5) + a6) + a7) + a8) + a9) + a10) + a11) + a12) + a13) + a14);


    printf("%d\n", a1);
    printf("%d\n", a2);
    printf("%d\n", a3);
    printf("%d\n", a4);
    printf("%d\n", a5);
    printf("%d\n", a6);
    printf("%d\n", a7);
    printf("%d\n", a8);
    printf("%d\n", a9);
    printf("%d\n", a10);
    printf("%d\n", a11);
    printf("%d\n", a12);
    printf("%d\n", a13);
    printf("%d\n", a14);
    printf("%d\n", a15);
    printf("%d\n", a16);
    printf("%d\n", a17);
    printf("%d\n", a18);
    printf("%d\n", a19);
    printf("%d\n", a20);
    printf("%d\n", a21);
    printf("%d\n", a22);
    printf("%d\n", a23);
    printf("%d\n", a24);
    printf("%d\n", a25);
    printf("%d\n", a26);
    printf("%d\n", a27);

    return 0;
}

int main() {

    int a;
    int b;
    int c;
    int d;
    int e;
    int f;
    int g;
    int h;
    int i;
    int j;
    int k;
    int l;
    int m;
    int n;
    int o;
    int p;
    int q;
    int r;

    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%d", &c);
    scanf("%d", &d);
    scanf("%d", &e);


    f = 10;
    i = 12;

    g = 5;
    h = 0;
    m = 22;
    p = 22;

    if ( (e + 5) > 12) {
        g = 10;
        o = m - 10;
        p = m - 10;
    } else {
        g = 10;
        h = 10;
        o = (m + 2) - 12;
        p = 10;
    }

    j = g * 5;
    k = h * 6;
    l = a * (6 + j);
    n = m * 4;
    q = (p + 3);
    r = (o + 3);

    printf("%d\n", a);
    printf("%d\n", b);
    printf("%d\n", c);
    printf("%d\n", d);
    printf("%d\n", e);
    printf("%d\n", f);
    printf("%d\n", g);
    printf("%d\n", h);
    printf("%d\n", i);
    printf("%d\n", j);
    printf("%d\n", k);
    printf("%d\n", l);
    printf("%d\n", m);
    printf("%d\n", n);
    printf("%d\n", o);
    printf("%d\n", p);
    printf("%d\n", q);
    printf("%d\n", r);


    return 0;
}

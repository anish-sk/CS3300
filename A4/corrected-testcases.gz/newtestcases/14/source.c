int main() {

	int a;
	int b;
	int c;
	int x;
	int z;

	scanf("%d", &a);
	scanf("%d", &b);

	z = (a+ (b*3)) + ((1-2)*45);
	x = (a*b) + (a+b);
	c = (a*(b*(3*7)));


	printf("%d\n", a);
	printf("%d\n", b);
	printf("%d\n", c);
	printf("%d\n", x);
	printf("%d\n", z);

	return 0;
}

int a;

int func( int a, int b[] , int c){

	while (a<5){

	a++;
	b++;
	func++;
	
}

while ((((((((a)))))))){
	a = (((b + (((c))))));
}
return (((a)));
}
